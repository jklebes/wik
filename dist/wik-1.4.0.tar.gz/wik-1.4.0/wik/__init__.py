"""wik is used to get information about anything on the shell using Wikipedia"""

__version__ = "1.4.0"

name = "wik"

__all__ = ["wik", "info"]
from wik import *
